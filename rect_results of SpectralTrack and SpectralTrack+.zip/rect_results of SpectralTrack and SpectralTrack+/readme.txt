yzcu --> SpectralTrack's result
yzcu+ --> SpectralTrack+'s result