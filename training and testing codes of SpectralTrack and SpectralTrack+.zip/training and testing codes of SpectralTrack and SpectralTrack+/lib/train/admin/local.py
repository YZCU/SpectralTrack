class EnvironmentSettings:
    def __init__(self):
        self.workspace_dir = ''
        self.tensorboard_dir = ''

        self.hotc2020_train_dir = r'G:\1datasets\48hotc2020\train_40\HSI'

        self.hotc2023_nir_dir = r'G:\1datasets\0hotc2023\train\NIR'

        self.hotc2023_rednir_dir = r'G:\1datasets\0hotc2023\train\RedNIR'

        self.hotc2023_vis_dir = r'G:\1datasets\0hotc2023\train\VIS'

        self.hotc2024_nir_dir = r'G:\1datasets\0hotc2024\train\NIR'

        self.hotc2024_rednir_dir = r'G:\1datasets\0hotc2024\train\RedNIR'

        self.hotc2024_vis_dir = r'G:\1datasets\0hotc2024\train\VIS'

        self.hotc2020_val_dir = r'G:\1datasets\48hotc2020\test_35\HSI'
