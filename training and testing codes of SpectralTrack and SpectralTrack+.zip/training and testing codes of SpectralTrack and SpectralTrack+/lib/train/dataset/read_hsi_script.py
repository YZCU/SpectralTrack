import numpy as np
from PIL import Image


def X2Cube(img, bands=16, skips=[4, 4]):
    B = skip = skips

    img = np.asarray(img)
    M, N = img.shape
    col_extent = N - B[1] + 1
    row_extent = M - B[0] + 1

    start_idx = np.arange(B[0])[:, None] * N + np.arange(B[1])

    didx = M * N * np.arange(1)
    start_idx = (didx[:, None] + start_idx.ravel()).reshape((-1, B[0], B[1]))

    offset_idx = np.arange(row_extent)[:, None] * N + np.arange(col_extent)

    out = np.take(img, start_idx.ravel()[:, None] + offset_idx[::skip[0], ::skip[1]].ravel())
    out = np.transpose(out)
    img = out.reshape(M // skip[0], N // skip[1], bands)

    img = img.astype(np.float32)
    channel_max = np.max(img, axis=(0, 1))
    channel_max = np.where(channel_max == 0, 1, channel_max)
    img /= channel_max
    img *= 255
    img = img.astype(np.uint8)

    return img


def read_hsi(image_path: str):
    image = Image.open(image_path)

    image = X2Cube(image, bands=16, skips=[4, 4])
    return image
