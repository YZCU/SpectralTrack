import torch
import torch.nn as nn
import torch.nn.functional as F


class EncoderFusion(nn.Module):
    def __init__(self, num_heads=8, d_model=512, dropout_rate=0.1):
        super(EncoderFusion, self).__init__()

        self.num_heads = num_heads
        self.d_model = d_model
        self.dropout_rate = dropout_rate

        self.layernorm = nn.LayerNorm(d_model)
        self.dense_key = nn.Linear(d_model * 5, d_model)
        self.dense_query = nn.Linear(d_model * 5, d_model)
        self.dense_value = nn.Linear(d_model * 5, d_model)
        self.dense_output = nn.Linear(d_model, d_model)

    def forward(self, encoder_out_list):
        concatenated_encoder_out = torch.cat(encoder_out_list, dim=-1)
        stack_res = torch.stack(encoder_out_list)
        mean_fused = torch.mean(stack_res, dim=0)
        queries = self.dense_query(concatenated_encoder_out)
        keys = self.dense_key(concatenated_encoder_out)
        values = self.dense_value(concatenated_encoder_out)

        def split_heads(x, batch_size):
            return x.view(batch_size, -1, self.num_heads, self.d_model // self.num_heads).permute(0, 2, 1, 3)

        batch_size = concatenated_encoder_out.size(0)
        queries = split_heads(queries, batch_size)
        keys = split_heads(keys, batch_size)
        values = split_heads(values, batch_size)
        queries *= torch.sqrt(torch.tensor(self.d_model // self.num_heads, dtype=torch.float32))
        keys *= torch.sqrt(torch.tensor(self.d_model // self.num_heads, dtype=torch.float32))
        attention_scores = torch.matmul(queries, keys.transpose(-2, -1)) / torch.sqrt(
            torch.tensor(self.d_model // self.num_heads, dtype=torch.float32))
        attention_scores = F.softmax(attention_scores, dim=-1)
        attention_scores = F.dropout(attention_scores, p=self.dropout_rate, training=self.training)
        output = torch.matmul(attention_scores, values)
        output = output.permute(0, 2, 1, 3).contiguous().view(batch_size, -1, self.d_model)
        output = self.dense_output(output)
        output = F.dropout(output, p=self.dropout_rate, training=self.training)
        output += mean_fused

        output = self.layernorm(output)

        return output


def build_encoder_fs():
    en_fs_module = EncoderFusion()

    return en_fs_module


if __name__ == '__main__':
    x0 = torch.randn(32, 320, 512)
    x1 = torch.randn(32, 320, 512)
    x2 = torch.randn(32, 320, 512)
    x3 = torch.randn(32, 320, 512)
    x4 = torch.randn(32, 320, 512)
    X = [x0, x1, x2, x3, x4]

    enc_fs_module = build_encoder_fs()

    fs_x = enc_fs_module(X)

    print(fs_x)
    print('\n', '融合结果fs_x形状: ', fs_x.shape)
