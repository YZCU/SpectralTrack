import torch
import torch.nn as nn
import torch.nn.functional as F


def token2feature(tokens):
    B, L, D = tokens.shape
    H = W = int(L ** 0.5)
    x = tokens.permute(0, 2, 1).view(B, D, W, H).contiguous()
    return x


def feature2token(x):
    B, C, W, H = x.shape
    L = W * H
    tokens = x.view(B, C, L).permute(0, 2, 1).contiguous()
    return tokens


def fast_xcorr(z, x):
    nz = z.size(0)
    nx, c, h, w = x.size()
    x = x.view(-1, nz * c, h, w)

    padding = (z.shape[2] - 1) // 2

    out = F.conv2d(x, z, padding=padding, groups=nz)
    out = out.view(nx, -1, out.size(-2), out.size(-1))
    return out


class tb_adapter(nn.Module):
    def __init__(self):
        super().__init__()
        in_channel = 512
        mid_channel = 4
        self.down_proj = nn.Linear(3 * in_channel, mid_channel)
        self.act = nn.ReLU()
        self.up_proj = nn.Linear(mid_channel, in_channel)
        self.scale = nn.Parameter(torch.ones(1))
        nn.init.zeros_(self.down_proj.weight)
        nn.init.zeros_(self.down_proj.bias)
        nn.init.zeros_(self.up_proj.weight)
        nn.init.zeros_(self.up_proj.bias)

    def forward(self, x):
        x = self.down_proj(x)
        x = self.act(x)
        x = self.up_proj(x)
        x = x * self.scale

        return x


class TBSI3LayerSimple(nn.Module):
    def __init__(self):
        super().__init__()
        self.t_adapter = tb_adapter()

    def forward(self, x0, x_hsi, x1):
        lens_z = 64
        x0_t = x0[:, :lens_z, :]
        x_hsi_t = x_hsi[:, :lens_z, :]
        x1_t = x1[:, :lens_z, :]
        x0_s = x0[:, lens_z:, :]
        x_hsi_s = x_hsi[:, lens_z:, :]
        x1_s = x1[:, lens_z:, :]
        fused_t = torch.cat([x0_t, x_hsi_t, x1_t], dim=2)
        fused_t = self.t_adapter(fused_t)
        fused_t_f = token2feature(fused_t)
        x0_s_f = token2feature(x0_s)
        sim = fast_xcorr(fused_t_f, x0_s_f)
        sim = F.interpolate(sim, size=(16, 16), mode='nearest')
        enc = x0_s_f * sim
        x0_p = feature2token(enc)
        x0_s_f = token2feature(x_hsi_s)
        sim = fast_xcorr(fused_t_f, x0_s_f)
        sim = F.interpolate(sim, size=(16, 16), mode='nearest')
        enc = x0_s_f * sim
        x_hsi_p = feature2token(enc)
        x0_s_f = token2feature(x1_s)
        sim = fast_xcorr(fused_t_f, x0_s_f)
        sim = F.interpolate(sim, size=(16, 16), mode='nearest')
        enc = x0_s_f * sim
        x1_p = feature2token(enc)
        x0[:, :lens_z, :] = x0[:, :lens_z, :] + fused_t
        x_hsi[:, :lens_z, :] = x_hsi[:, :lens_z, :] + fused_t
        x1[:, :lens_z, :] = x1[:, :lens_z, :] + fused_t
        x0[:, lens_z:, :] = x0[:, lens_z:, :] + x0_p
        x_hsi[:, lens_z:, :] = x_hsi[:, lens_z:, :] + x_hsi_p
        x1[:, lens_z:, :] = x1[:, lens_z:, :] + x1_p

        return x0, x_hsi, x1


if __name__ == "__main__":
    x0 = torch.randn([32, 320, 512])
    x_hsi = torch.randn([32, 320, 512])
    x1 = torch.randn([32, 320, 512])

    tbsi = TBSI3LayerSimple()

    x0, x_hsi, x1 = tbsi(x0, x_hsi, x1)

    print(x0.shape)
