import torch
import torch.nn as nn


class stm_TransformerFusion(nn.Module):
    def __init__(self, input_dim=512, num_heads=8, num_layers=1):
        super(stm_TransformerFusion, self).__init__()

        self.num_heads = num_heads
        self.num_layers = num_layers
        encoder_layer = nn.TransformerEncoderLayer(d_model=input_dim, nhead=num_heads)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

    def forward(self, enc_opt, out_dec):
        x = torch.cat((enc_opt, out_dec), dim=-2)

        x = self.transformer(x)

        x = x[:, :-1]

        return x


def build_vit_selfatt():
    input_dim = 512
    num_heads = 8
    num_layers = 1

    return stm_TransformerFusion(input_dim=input_dim, num_heads=num_heads, num_layers=num_layers)


if __name__ == "__main__":
    input_dim = 512
    num_heads = 8
    num_layers = 1

    fusion_model = stm_TransformerFusion(input_dim=input_dim, num_heads=num_heads, num_layers=num_layers)
    enc_opt = torch.randn([32, 256, 512])
    out_dec = torch.randn([32, 1, 512])
    output = fusion_model(enc_opt, out_dec)
    print(output.shape)
