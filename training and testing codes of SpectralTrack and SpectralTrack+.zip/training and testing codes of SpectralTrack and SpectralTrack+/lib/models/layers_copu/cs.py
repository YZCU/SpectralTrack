"""channel selection (cs)"""
import torch
import torch.nn as nn
import torch.nn.functional as F


def Split_Channel(feat_channel, order):
    band_res = []
    b = feat_channel.size()[0]
    order_falsecolor_importance = [[None for j in range(b)] for i in range(5)]
    order_band_importance = order[0]
    order_band = order[1]
    for i in range(5):
        select_three_band = order_band[0, i * 3:i * 3 + 3]
        gg = feat_channel[None, 0, select_three_band, :, :]
        order_falsecolor_importance[i][0] = order_band_importance[0, i * 3:i * 3 + 3].detach().mean().item()
        for k in range(1, b):
            select_three_band_one = order_band[k, i * 3:i * 3 + 3]
            gg = torch.cat((gg, feat_channel[None, k, select_three_band_one, :, :]), dim=0)
            order_falsecolor_importance[i][k] = order_band_importance[k,
                                                i * 3:i * 3 + 3].detach().mean().item()
        band_res.append(gg)
    return band_res, order_falsecolor_importance


class ConvBnrelu2d_1(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=1, padding=0, stride=1, dilation=1, groups=1, bias=False):
        super(ConvBnrelu2d_1, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=padding, stride=stride,
                              dilation=dilation, groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_channels)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.xavier_uniform_(m.weight.data)
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
    def forward(self, x):
        return F.relu(self.bn(self.conv(x)))


class DilationConvBn2d_3(nn.Module):

    def __init__(self, in_channels, out_channels, dilation, padding, kernel_size=3, stride=1, groups=1, bias=False):
        super(DilationConvBn2d_3, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=padding, stride=stride,
                              dilation=dilation, groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_channels)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.xavier_uniform_(m.weight.data)
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def forward(self, x):
        return F.relu(self.bn(self.conv(x)))


class My_ASPP(nn.Module):
    def __init__(self, in_channels, mid_channels):
        super(My_ASPP, self).__init__()
        self.conv1 = ConvBnrelu2d_1(in_channels, mid_channels)
        self.Dconv1 = DilationConvBn2d_3(mid_channels, mid_channels, dilation=1, padding=1)
        self.conv2 = ConvBnrelu2d_1(in_channels, mid_channels)
        self.Dconv2 = DilationConvBn2d_3(mid_channels, mid_channels, dilation=6, padding=6)
        self.conv3 = ConvBnrelu2d_1(in_channels, mid_channels)
        self.Dconv3 = DilationConvBn2d_3(mid_channels, mid_channels, dilation=12, padding=12)
        self.conv0 = ConvBnrelu2d_1(in_channels, mid_channels)
        self.conv4_0 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv5_0 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv4 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv5 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv4_00 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv5_00 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv40 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv50 = ConvBnrelu2d_1(mid_channels, mid_channels)

        self.conv4_000 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv5_000 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv400 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.conv500 = ConvBnrelu2d_1(mid_channels, mid_channels)
        self.fuse_dconv = ConvBnrelu2d_1(4 * mid_channels, in_channels)

    def forward(self, x):
        x_1 = self.Dconv1(self.conv1(x))
        x_2 = self.Dconv2(self.conv2(x))
        x_3 = self.Dconv3(self.conv3(x))
        x_0 = self.conv0(x)

        x_1_cos = self.conv5_0(x_1 * torch.cos(x_1))
        x_1_sin = self.conv4_0(x_1 * torch.sin(x_1))
        multiplication_1 = self.conv4(x_1_sin * x_1_cos)
        summation_1 = self.conv5(x_1_sin + x_1_cos)
        fus_1 = summation_1 + multiplication_1
        x_2_cos = self.conv5_00(x_2 * torch.cos(x_2))
        x_2_sin = self.conv4_00(x_2 * torch.sin(x_2))
        multiplication_2 = self.conv40(x_2_sin * x_2_cos)
        summation_2 = self.conv50(x_2_sin + x_2_cos)
        fus_2 = summation_2 + multiplication_2
        x_3_cos = self.conv5_000(x_3 * torch.cos(x_3))
        x_3_sin = self.conv4_000(x_3 * torch.sin(x_3))
        multiplication_3 = self.conv400(x_3_sin * x_3_cos)
        summation_3 = self.conv500(x_3_sin + x_3_cos)
        fus_3 = summation_3 + multiplication_3
        out_cat = torch.cat((fus_1, fus_2, fus_3, x_0), dim=1)
        out = self.fuse_dconv(out_cat)
        return out


class CS(nn.Module):
    def __init__(self):
        super(CS, self).__init__()
        in_channels = 16
        mid_channels = 8

        self.my_ASPP = My_ASPP(in_channels=in_channels,
                               mid_channels=mid_channels)

        self.mlp = nn.Sequential(nn.Linear(in_channels, in_channels, bias=True),
                                 nn.ReLU(),
                                 nn.Linear(in_channels, in_channels, bias=True),
                                 nn.ReLU())

        self.soft = nn.Softmax(dim=-1)

    def forward(self, x):
        input = x
        b1, c1, w1, h1 = x.size()

        x1 = self.my_ASPP(x)

        b, c, w, h = x1.size()
        x2 = x1.view(b, c, -1)
        x3 = x2.permute(0, 2, 1)

        w0 = self.mlp(x3)

        res = w0.permute(0, 2, 1)
        y0 = res.mean(dim=2)
        y1 = y0.view(b, 16, 1)
        ty = y1.permute(0, 2, 1)

        C0 = torch.bmm(y1, ty)

        for i in range(16):
            C0[:, i, i] = 0.0

        C = C0 / C0.max()

        w = torch.norm(C, p=2, dim=2)

        orderY = torch.sort(w, dim=-1, descending=True, out=None)

        fc_img, weight = Split_Channel(x, orderY)

        a = input.view(b1, c1, -1)
        cg_hsi = torch.bmm(C, a)

        return fc_img, weight, orderY, cg_hsi


def build_cs():
    return CS()


if __name__ == '__main__':
    x = torch.randn(32, 16, 128, 128)
    channel_net = build_cs()

    fc_img, weight, orderY, cg_res = channel_net(x)

    loss = nn.MSELoss()(x.view(x.shape[0], x.shape[1], -1), cg_res) + 0.001 * sum(
        torch.norm(param, p=2) for param in channel_net.parameters())

    print(weight)

    print(cg_res.shape)
