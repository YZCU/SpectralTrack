import torch
from torch import nn


class inter_adapter(nn.Module):
    def __init__(self):
        super().__init__()
        in_channel = 512
        mid_channel = 4
        self.down_proj = nn.Linear(in_channel, mid_channel)
        self.act = nn.ReLU()
        self.up_proj = nn.Linear(mid_channel, in_channel)
        self.scale = nn.Parameter(torch.ones(1))
        nn.init.zeros_(self.down_proj.weight)
        nn.init.zeros_(self.down_proj.bias)
        nn.init.zeros_(self.up_proj.weight)
        nn.init.zeros_(self.up_proj.bias)

    def forward(self, x):
        x = self.down_proj(x)
        x = self.act(x)
        x = self.up_proj(x)
        x = x * self.scale
        return x


if __name__ == "__main__":
    x = torch.randn([32, 320, 512])
    adapter = inter_adapter()
    out = adapter(x)
    print(out.shape)
