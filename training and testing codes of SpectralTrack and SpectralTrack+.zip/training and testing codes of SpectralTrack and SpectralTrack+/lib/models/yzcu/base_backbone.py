from functools import partial

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms.functional as tvisf
from timm.models.layers import to_2tuple
from lib.models.yzcu.utils import combine_tokens, recover_tokens, split_channel


class BaseBackbone(nn.Module):
    def __init__(self):
        super().__init__()

        self.pos_embed = None
        self.img_size = [224, 224]
        self.patch_size = 16
        self.embed_dim = 384
        self.cat_mode = 'direct'
        self.pos_embed_z = None
        self.pos_embed_x = None
        self.template_segment_pos_embed = None
        self.search_segment_pos_embed = None
        self.return_inter = False
        self.return_stage = [2, 5, 8, 11]
        self.add_cls_token = False
        self.add_sep_seg = False

    def finetune_track(self, cfg, patch_start_index=1):
        search_size = to_2tuple(cfg.DATA.SEARCH.SIZE)
        template_size = to_2tuple(cfg.DATA.TEMPLATE.SIZE)
        new_patch_size = cfg.MODEL.BACKBONE.STRIDE
        self.cat_mode = cfg.MODEL.BACKBONE.CAT_MODE
        self.return_inter = cfg.MODEL.RETURN_INTER
        patch_pos_embed = self.absolute_pos_embed
        patch_pos_embed = patch_pos_embed.transpose(1, 2)
        B, E, Q = patch_pos_embed.shape
        P_H, P_W = self.img_size[0] // self.patch_size, self.img_size[1] // self.patch_size
        patch_pos_embed = patch_pos_embed.view(B, E, P_H, P_W)
        H, W = search_size
        new_P_H, new_P_W = H // new_patch_size, W // new_patch_size
        search_patch_pos_embed = nn.functional.interpolate(patch_pos_embed, size=(new_P_H, new_P_W), mode='bicubic',
                                                           align_corners=False)
        search_patch_pos_embed = search_patch_pos_embed.flatten(2).transpose(1, 2)
        H, W = template_size
        new_P_H, new_P_W = H // new_patch_size, W // new_patch_size
        template_patch_pos_embed = nn.functional.interpolate(patch_pos_embed, size=(new_P_H, new_P_W), mode='bicubic',
                                                             align_corners=False)
        template_patch_pos_embed = template_patch_pos_embed.flatten(2).transpose(1, 2)
        self.pos_embed_z = nn.Parameter(template_patch_pos_embed)
        self.pos_embed_x = nn.Parameter(search_patch_pos_embed)

        if self.return_inter:
            for i_layer in self.fpn_stage:
                if i_layer != 11:
                    norm_layer = partial(nn.LayerNorm, eps=1e-6)
                    layer = norm_layer(self.embed_dim)
                    layer_name = f'norm{i_layer}'
                    self.add_module(layer_name, layer)

    def fft_hsi(self, x, rate, prompt_type):
        mask = torch.zeros(x.shape)
        w, h = x.shape[-2:]
        line = int((w * h * rate) ** .5 // 2)
        mask[:, :, w // 2 - line:w // 2 + line, h // 2 - line:h // 2 + line] = 1
        fft = torch.fft.fftshift(torch.fft.fft2(x, norm="forward"))
        if prompt_type == 'highpass':
            fft = fft * (1 - mask).cuda()
        elif prompt_type == 'lowpass':
            fft = fft * mask
        fr = fft.real
        fi = fft.imag
        fft_hires = torch.fft.ifftshift(torch.complex(fr, fi))
        inv = torch.fft.ifft2(fft_hires, norm="forward").real
        inv = torch.abs(inv)

        return inv

    def forward_features(self, z, x, mask=None):
        freq_nums = 0.25
        prompt_type = 'highpass'
        x_ori = x
        z_ori = z
        avg_pool = nn.AvgPool2d(kernel_size=3, stride=3)
        x16 = self.cs_patch_embed16_img_hsi(x)
        x_fft = self.fft_hsi(x, freq_nums, prompt_type)
        x16_fft = self.cs_patch_embed16_fft_hsi(x_fft)
        x16 = (avg_pool(x16)).flatten(2).transpose(1, 2)
        x16_fft = (avg_pool(x16_fft)).flatten(2).transpose(1, 2)
        ms_p = x16 + x16_fft
        ms_mlp = self.cs_mlp_hsi(ms_p)
        ms_mlp_ = ms_mlp.transpose(1, 2)
        cm = torch.matmul(ms_mlp_, ms_mlp)
        for i in range(15):
            cm[:, i, i] = 0.0
        cm = F.normalize(cm, p=2, dim=-1)
        for i in range(15):
            cm[:, i, i] = 0.0
        w = torch.norm(cm, p=1, dim=-1)
        w_reshape = w.contiguous().view(w.shape[0], w.shape[1], 1, 1)
        x_att = w_reshape.expand_as(x)
        x_cg = x * x_att
        x_cg = x_cg.view(x_cg.shape[0], x_cg.shape[1], -1)
        z_att = w_reshape.expand_as(z)
        z_cg = z * z_att
        z_cg = z_cg.view(z_cg.shape[0], z_cg.shape[1], -1)
        z_orig = z.view(z.shape[0], z.shape[1], -1)
        x_orig = x.view(x.shape[0], x.shape[1], -1)
        cg_res = [z_orig, x_orig, z_cg, x_cg]
        orderY = torch.sort(w, dim=-1, descending=True, out=None)
        x_fc_list, _ = split_channel(x, orderY)
        z_fc_list, _ = split_channel(z, orderY)
        z0, z1 = z_fc_list[0], z_fc_list[1]
        x0, x1 = x_fc_list[0], x_fc_list[1]
        imgnet_mean = torch.tensor([0.485, 0.456, 0.406]).cuda()
        imgnet_std = torch.tensor([0.229, 0.224, 0.225]).cuda()
        imgnet_hsi_mean = imgnet_mean.mean().expand(z_ori.shape[1])
        imgnet_hsi_std = imgnet_std.mean().expand(z_ori.shape[1])
        z0 = tvisf.normalize(z0, imgnet_mean, imgnet_std)
        z1 = tvisf.normalize(z1, imgnet_mean, imgnet_std)
        z_hsi = tvisf.normalize(z_ori, imgnet_hsi_mean, imgnet_hsi_std)
        x0 = tvisf.normalize(x0, imgnet_mean, imgnet_std)
        x1 = tvisf.normalize(x1, imgnet_mean, imgnet_std)
        x_hsi = tvisf.normalize(x_ori, imgnet_hsi_mean, imgnet_hsi_std)
        z0 = self.patch_embed(z0)
        x0 = self.patch_embed(x0)
        z_hsi = self.patch_embed_hsi(z_hsi)
        x_hsi = self.patch_embed_hsi(x_hsi)
        z1 = self.patch_embed(z1)
        x1 = self.patch_embed(x1)
        for blk in self.blocks[:-self.num_main_blocks]:
            z0, z_hsi, z1 = blk(z0, z_hsi, z1)
            x0, x_hsi, x1 = blk(x0, x_hsi, x1)

        z0 = z0[..., 0, 0, :]
        x0 = x0[..., 0, 0, :]

        z_hsi = z_hsi[..., 0, 0, :]
        x_hsi = x_hsi[..., 0, 0, :]

        z1 = z1[..., 0, 0, :]
        x1 = x1[..., 0, 0, :]

        z0 += self.pos_embed_z
        x0 += self.pos_embed_x
        lens_z = self.pos_embed_z.shape[1]
        lens_x = self.pos_embed_x.shape[1]

        z_hsi += self.pos_embed_z
        x_hsi += self.pos_embed_x

        z1 += self.pos_embed_z
        x1 += self.pos_embed_x

        x0 = combine_tokens(z0, x0, mode=self.cat_mode)
        x_hsi = combine_tokens(z_hsi, x_hsi, mode=self.cat_mode)
        x1 = combine_tokens(z1, x1, mode=self.cat_mode)

        x0 = self.pos_drop(x0)
        x_hsi = self.pos_drop(x_hsi)
        x1 = self.pos_drop(x1)

        for blk in self.blocks[-self.num_main_blocks:]:
            x0, x_hsi, x1 = blk(x0, x_hsi, x1)

        x = x0 + x_hsi + x1

        x = recover_tokens(x, lens_z, lens_x, mode=self.cat_mode)
        aux_dict = {"attn": None}

        x = self.norm_(x)

        return x, aux_dict, cg_res, orderY

    def forward(self, z, x, **kwargs):
        x, aux_dict, cg_res, orderY = self.forward_features(z, x, )
        return x, aux_dict, cg_res, orderY
