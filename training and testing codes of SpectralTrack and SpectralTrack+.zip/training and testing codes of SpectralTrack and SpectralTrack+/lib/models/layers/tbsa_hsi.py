import torch
import torch.nn as nn


class tb_hsi(nn.Module):
    def __init__(self):
        super().__init__()
        in_channel = 512
        mid_channel = 4
        self.down_proj = nn.Linear(in_channel, mid_channel)
        self.act = nn.ReLU()
        self.up_proj = nn.Linear(mid_channel, in_channel)
        self.scale = nn.Parameter(torch.ones(1))
        nn.init.zeros_(self.down_proj.weight)
        nn.init.zeros_(self.down_proj.bias)
        nn.init.zeros_(self.up_proj.weight)
        nn.init.zeros_(self.up_proj.bias)

    def forward(self, x):
        x = self.down_proj(x)
        x = self.act(x)
        x = self.up_proj(x)
        x = x * self.scale
        return x


class tbsa_hsi(nn.Module):
    def __init__(self):
        super().__init__()
        self.t_adapter = tb_hsi()

    def forward(self, x0, x_hsi):
        lens_z = 64
        x0_org, x_hsi_org = x0, x_hsi
        x0_t = x0[:, :lens_z, :]
        x_hsi_t = x_hsi[:, :lens_z, :]
        x0_s = x0[:, lens_z:, :]
        x_hsi_s = x_hsi[:, lens_z:, :]
        fused_t = (x0_t + x_hsi_t) / 2
        g_t = fused_t.mean(dim=1, keepdim=True)
        g_t = g_t.transpose(1, 2)
        att1 = torch.matmul(x_hsi_s, g_t)
        opt1 = x0_s.unsqueeze(-1) * att1.unsqueeze(-2)
        opt1 = opt1.squeeze(-1)
        att2 = torch.matmul(x0_s, g_t)
        opt2 = x_hsi_s.unsqueeze(-1) * att2.unsqueeze(-2)
        opt2 = opt2.squeeze(-1)
        opt1 = torch.cat((fused_t, opt1), dim=1)
        opt2 = torch.cat((fused_t, opt2), dim=1)
        out_up = self.t_adapter(x_hsi_org + opt1)
        out_down = self.t_adapter(x0_org + opt2)
        return out_up, out_down
