import torch
import torch.nn as nn


class Attention(nn.Module):
    def __init__(self, dim, num_heads, qkv_bias=True, qk_scale=None, attn_drop=0., proj_drop=0., ):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]

        q = q * self.scale
        attn = (q @ k.transpose(-2, -1))

        attn = attn.float().clamp(min=torch.finfo(torch.float32).min, max=torch.finfo(torch.float32).max)
        attn = self.softmax(attn)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class hma_fusion_hsi(nn.Module):
    def __init__(self, dim=512, num_heads=8):
        super(hma_fusion_hsi, self).__init__()
        mlp_ratio = 4.0

        self.norm1 = nn.LayerNorm(dim)
        self.attn = Attention(dim=dim, num_heads=num_heads)

        self.norm2 = nn.LayerNorm(dim)

    def forward(self, enc_opt, out_dec):
        x = torch.cat((enc_opt, out_dec), dim=-2)
        x = x + self.attn(self.norm1(x))
        x = self.norm2(x)
        x = x[:, :-1]
        return x


def build_hma_hsi():
    return hma_fusion_hsi(dim=512, num_heads=8)

