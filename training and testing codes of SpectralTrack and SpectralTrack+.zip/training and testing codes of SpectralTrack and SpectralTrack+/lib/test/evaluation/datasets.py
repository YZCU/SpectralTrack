from collections import namedtuple
import importlib
from lib.test.evaluation.data import SequenceList

DatasetInfo = namedtuple('DatasetInfo', ['module', 'class_name', 'kwargs'])

pt = "lib.test.evaluation.%sdataset"  


dataset_dict = dict(
    
    hotc2020=DatasetInfo(module=pt % "hotc2020", class_name="hotc2020Dataset", kwargs=dict()),
    hotc2023_nir=DatasetInfo(module=pt % "hotc2023_nir", class_name="hotc2023_nirDataset", kwargs=dict()),
    hotc2023_rednir=DatasetInfo(module=pt % "hotc2023_rednir", class_name="hotc2023_rednirDataset", kwargs=dict()),
    hotc2023_vis=DatasetInfo(module=pt % "hotc2023_vis", class_name="hotc2023_visDataset", kwargs=dict()),
    hotc2024_nir=DatasetInfo(module=pt % "hotc2024_nir", class_name="hotc2024_nirDataset", kwargs=dict()),
    hotc2024_rednir=DatasetInfo(module=pt % "hotc2024_rednir", class_name="hotc2024_rednirDataset", kwargs=dict()),
    hotc2024_vis=DatasetInfo(module=pt % "hotc2024_vis", class_name="hotc2024_visDataset", kwargs=dict()),
    msvt=DatasetInfo(module=pt % "msvt", class_name="msvtDataset", kwargs=dict()),
    mssot=DatasetInfo(module=pt % "mssot", class_name="mssotDataset", kwargs=dict()),
)


def load_dataset(name: str):
    """ Import and load a single dataset."""
    name = name.lower()
    dset_info = dataset_dict.get(name)
    if dset_info is None:
        raise ValueError('Unknown dataset \'%s\'' % name)

    m = importlib.import_module(dset_info.module)
    dataset = getattr(m, dset_info.class_name)(**dset_info.kwargs)  
    return dataset.get_sequence_list()


def get_dataset(*args):
    """ Get a single or set of datasets."""
    dset = SequenceList()
    for name in args:
        dset.extend(load_dataset(name))
    return dset