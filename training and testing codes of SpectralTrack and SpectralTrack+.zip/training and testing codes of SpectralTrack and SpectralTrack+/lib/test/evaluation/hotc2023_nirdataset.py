import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text


class hotc2023_nirDataset(BaseDataset):

    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.hotc2023_nir_path
        self.sequence_info_list = self._get_sequence_info_list()

    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_info_list])

    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        nz = sequence_info['nz']
        ext = sequence_info['ext']
        start_frame = sequence_info['startFrame']
        end_frame = sequence_info['endFrame']

        init_omit = 0
        if 'initOmit' in sequence_info:
            init_omit = sequence_info['initOmit']

        frames = ['{base_path}/{sequence_path}/{frame:0{nz}}.{ext}'.format(base_path=self.base_path,
                                                                           sequence_path=sequence_path, frame=frame_num,
                                                                           nz=nz, ext=ext) for frame_num in
                  range(start_frame + init_omit, end_frame + 1)]

        anno_path = '{}/{}'.format(self.base_path, sequence_info['anno_path'])

        ground_truth_rect = load_text(str(anno_path), delimiter=(',', None), dtype=np.float64, backend='numpy')

        return Sequence(sequence_info['name'], frames, 'hotc2023_nir', ground_truth_rect[init_omit:, :],
                        object_class=sequence_info['object_class'])

    def __len__(self):
        return len(self.sequence_info_list)

    def _get_sequence_info_list(self):
        sequence_info_list = [
            {"name": "basketball3", "path": "basketball3", "startFrame": 1, "endFrame": 778, "nz": 4, "ext": "png",
             "anno_path": "basketball3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car11", "path": "car11", "startFrame": 1, "endFrame": 101, "nz": 4, "ext": "png",
             "anno_path": "car11/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car12", "path": "car12", "startFrame": 1, "endFrame": 182, "nz": 4, "ext": "png",
             "anno_path": "car12/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car49", "path": "car49", "startFrame": 1, "endFrame": 150, "nz": 4, "ext": "png",
             "anno_path": "car49/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car50", "path": "car50", "startFrame": 1, "endFrame": 155, "nz": 4, "ext": "png",
             "anno_path": "car50/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car51", "path": "car51", "startFrame": 1, "endFrame": 102, "nz": 4, "ext": "png",
             "anno_path": "car51/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car52", "path": "car52", "startFrame": 1, "endFrame": 93, "nz": 4, "ext": "png",
             "anno_path": "car52/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car53", "path": "car53", "startFrame": 1, "endFrame": 160, "nz": 4, "ext": "png",
             "anno_path": "car53/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car59", "path": "car59", "startFrame": 1, "endFrame": 185, "nz": 4, "ext": "png",
             "anno_path": "car59/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car60", "path": "car60", "startFrame": 1, "endFrame": 82, "nz": 4, "ext": "png",
             "anno_path": "car60/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car61", "path": "car61", "startFrame": 1, "endFrame": 127, "nz": 4, "ext": "png",
             "anno_path": "car61/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car62", "path": "car62", "startFrame": 1, "endFrame": 159, "nz": 4, "ext": "png",
             "anno_path": "car62/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car63", "path": "car63", "startFrame": 1, "endFrame": 151, "nz": 4, "ext": "png",
             "anno_path": "car63/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car64", "path": "car64", "startFrame": 1, "endFrame": 68, "nz": 4, "ext": "png",
             "anno_path": "car64/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car76", "path": "car76", "startFrame": 1, "endFrame": 138, "nz": 4, "ext": "png",
             "anno_path": "car76/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car77", "path": "car77", "startFrame": 1, "endFrame": 93, "nz": 4, "ext": "png",
             "anno_path": "car77/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car78", "path": "car78", "startFrame": 1, "endFrame": 119, "nz": 4, "ext": "png",
             "anno_path": "car78/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car79", "path": "car79", "startFrame": 1, "endFrame": 132, "nz": 4, "ext": "png",
             "anno_path": "car79/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car80", "path": "car80", "startFrame": 1, "endFrame": 164, "nz": 4, "ext": "png",
             "anno_path": "car80/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car81", "path": "car81", "startFrame": 1, "endFrame": 111, "nz": 4, "ext": "png",
             "anno_path": "car81/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car82", "path": "car82", "startFrame": 1, "endFrame": 105, "nz": 4, "ext": "png",
             "anno_path": "car82/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car83", "path": "car83", "startFrame": 1, "endFrame": 122, "nz": 4, "ext": "png",
             "anno_path": "car83/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car84", "path": "car84", "startFrame": 1, "endFrame": 178, "nz": 4, "ext": "png",
             "anno_path": "car84/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car85", "path": "car85", "startFrame": 1, "endFrame": 155, "nz": 4, "ext": "png",
             "anno_path": "car85/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pedestrian7", "path": "pedestrian7", "startFrame": 1, "endFrame": 271, "nz": 4, "ext": "png",
             "anno_path": "pedestrian7/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rider11", "path": "rider11", "startFrame": 1, "endFrame": 142, "nz": 4, "ext": "png",
             "anno_path": "rider11/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rider16", "path": "rider16", "startFrame": 1, "endFrame": 184, "nz": 4, "ext": "png",
             "anno_path": "rider16/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rider17", "path": "rider17", "startFrame": 1, "endFrame": 165, "nz": 4, "ext": "png",
             "anno_path": "rider17/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rider18", "path": "rider18", "startFrame": 1, "endFrame": 124, "nz": 4, "ext": "png",
             "anno_path": "rider18/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rider19", "path": "rider19", "startFrame": 1, "endFrame": 160, "nz": 4, "ext": "png",
             "anno_path": "rider19/groundtruth_rect.txt", "object_class": "person"}]

        return sequence_info_list
