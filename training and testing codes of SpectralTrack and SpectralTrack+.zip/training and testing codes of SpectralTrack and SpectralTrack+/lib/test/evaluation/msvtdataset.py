import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text


class msvtDataset(BaseDataset):

    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.msvt_path
        self.sequence_info_list = self._get_sequence_info_list()

    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_info_list])

    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        nz = sequence_info['nz']
        ext = sequence_info['ext']
        start_frame = sequence_info['startFrame']
        end_frame = sequence_info['endFrame']

        init_omit = 0
        if 'initOmit' in sequence_info:
            init_omit = sequence_info['initOmit']

        frames = ['{base_path}/{sequence_path}/{frame:0{nz}}.{ext}'.format(base_path=self.base_path,
                                                                           sequence_path=sequence_path, frame=frame_num,
                                                                           nz=nz, ext=ext) for frame_num in
                  range(start_frame + init_omit, end_frame + 1)]

        anno_path = '{}/{}'.format(self.base_path, sequence_info['anno_path'])

        ground_truth_rect = load_text(str(anno_path), delimiter=(',', None), dtype=np.float64, backend='numpy')

        return Sequence(sequence_info['name'], frames, 'msvt', ground_truth_rect[init_omit:, :],
                        object_class=sequence_info['object_class'])

    def __len__(self):
        return len(self.sequence_info_list)

    def _get_sequence_info_list(self):
        sequence_info_list = [
            {"name": "airplane", "path": "airplane/imgs/", "startFrame": 1, "endFrame": 290, "nz": 4, "ext": "tif",
             "anno_path": "airplane/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane1", "path": "airplane1/imgs/", "startFrame": 1, "endFrame": 240, "nz": 4, "ext": "tif",
             "anno_path": "airplane1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane10", "path": "airplane10/imgs/", "startFrame": 1, "endFrame": 74, "nz": 4, "ext": "tif",
             "anno_path": "airplane10/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane11", "path": "airplane11/imgs/", "startFrame": 1, "endFrame": 70, "nz": 4, "ext": "tif",
             "anno_path": "airplane11/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane12", "path": "airplane12/imgs/", "startFrame": 1, "endFrame": 95, "nz": 4, "ext": "tif",
             "anno_path": "airplane12/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane13", "path": "airplane13/imgs/", "startFrame": 1, "endFrame": 153, "nz": 4, "ext": "tif",
             "anno_path": "airplane13/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane14", "path": "airplane14/imgs/", "startFrame": 1, "endFrame": 120, "nz": 4, "ext": "tif",
             "anno_path": "airplane14/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane2", "path": "airplane2/imgs/", "startFrame": 1, "endFrame": 70, "nz": 4, "ext": "tif",
             "anno_path": "airplane2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane3", "path": "airplane3/imgs/", "startFrame": 1, "endFrame": 56, "nz": 4, "ext": "tif",
             "anno_path": "airplane3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane4", "path": "airplane4/imgs/", "startFrame": 1, "endFrame": 118, "nz": 4, "ext": "tif",
             "anno_path": "airplane4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane5", "path": "airplane5/imgs/", "startFrame": 1, "endFrame": 84, "nz": 4, "ext": "tif",
             "anno_path": "airplane5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane6", "path": "airplane6/imgs/", "startFrame": 1, "endFrame": 99, "nz": 4, "ext": "tif",
             "anno_path": "airplane6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane7", "path": "airplane7/imgs/", "startFrame": 1, "endFrame": 105, "nz": 4, "ext": "tif",
             "anno_path": "airplane7/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane8", "path": "airplane8/imgs/", "startFrame": 1, "endFrame": 216, "nz": 4, "ext": "tif",
             "anno_path": "airplane8/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane9", "path": "airplane9/imgs/", "startFrame": 1, "endFrame": 300, "nz": 4, "ext": "tif",
             "anno_path": "airplane9/groundtruth_rect.txt", "object_class": "person"},
            {"name": "bicycle", "path": "bicycle/imgs/", "startFrame": 1, "endFrame": 208, "nz": 4, "ext": "tif",
             "anno_path": "bicycle/groundtruth_rect.txt", "object_class": "person"},
            {"name": "bicycle1", "path": "bicycle1/imgs/", "startFrame": 1, "endFrame": 61, "nz": 4, "ext": "tif",
             "anno_path": "bicycle1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "bicycle2", "path": "bicycle2/imgs/", "startFrame": 1, "endFrame": 96, "nz": 4, "ext": "tif",
             "anno_path": "bicycle2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "bicycle3", "path": "bicycle3/imgs/", "startFrame": 1, "endFrame": 99, "nz": 4, "ext": "tif",
             "anno_path": "bicycle3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat", "path": "boat/imgs/", "startFrame": 1, "endFrame": 71, "nz": 4, "ext": "tif",
             "anno_path": "boat/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat1", "path": "boat1/imgs/", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "tif",
             "anno_path": "boat1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat10", "path": "boat10/imgs/", "startFrame": 1, "endFrame": 400, "nz": 4, "ext": "tif",
             "anno_path": "boat10/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat11", "path": "boat11/imgs/", "startFrame": 1, "endFrame": 400, "nz": 4, "ext": "tif",
             "anno_path": "boat11/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat12", "path": "boat12/imgs/", "startFrame": 1, "endFrame": 150, "nz": 4, "ext": "tif",
             "anno_path": "boat12/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat2", "path": "boat2/imgs/", "startFrame": 1, "endFrame": 200, "nz": 4, "ext": "tif",
             "anno_path": "boat2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat3", "path": "boat3/imgs/", "startFrame": 1, "endFrame": 70, "nz": 4, "ext": "tif",
             "anno_path": "boat3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat4", "path": "boat4/imgs/", "startFrame": 1, "endFrame": 400, "nz": 4, "ext": "tif",
             "anno_path": "boat4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat5", "path": "boat5/imgs/", "startFrame": 1, "endFrame": 300, "nz": 4, "ext": "tif",
             "anno_path": "boat5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat6", "path": "boat6/imgs/", "startFrame": 1, "endFrame": 200, "nz": 4, "ext": "tif",
             "anno_path": "boat6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat7", "path": "boat7/imgs/", "startFrame": 1, "endFrame": 200, "nz": 4, "ext": "tif",
             "anno_path": "boat7/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat8", "path": "boat8/imgs/", "startFrame": 1, "endFrame": 600, "nz": 4, "ext": "tif",
             "anno_path": "boat8/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat9", "path": "boat9/imgs/", "startFrame": 1, "endFrame": 400, "nz": 4, "ext": "tif",
             "anno_path": "boat9/groundtruth_rect.txt", "object_class": "person"},
            {"name": "bottle", "path": "bottle/imgs/", "startFrame": 1, "endFrame": 170, "nz": 4, "ext": "tif",
             "anno_path": "bottle/groundtruth_rect.txt", "object_class": "person"},
            {"name": "camera", "path": "camera/imgs/", "startFrame": 1, "endFrame": 200, "nz": 4, "ext": "tif",
             "anno_path": "camera/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car", "path": "car/imgs/", "startFrame": 1, "endFrame": 65, "nz": 4, "ext": "tif",
             "anno_path": "car/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car1", "path": "car1/imgs/", "startFrame": 1, "endFrame": 130, "nz": 4, "ext": "tif",
             "anno_path": "car1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car2", "path": "car2/imgs/", "startFrame": 1, "endFrame": 150, "nz": 4, "ext": "tif",
             "anno_path": "car2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car3", "path": "car3/imgs/", "startFrame": 1, "endFrame": 112, "nz": 4, "ext": "tif",
             "anno_path": "car3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car4", "path": "car4/imgs/", "startFrame": 1, "endFrame": 75, "nz": 4, "ext": "tif",
             "anno_path": "car4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car5", "path": "car5/imgs/", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "tif",
             "anno_path": "car5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car6", "path": "car6/imgs/", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "tif",
             "anno_path": "car6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "double", "path": "double/imgs/", "startFrame": 1, "endFrame": 320, "nz": 4, "ext": "tif",
             "anno_path": "double/groundtruth_rect.txt", "object_class": "person"},
            {"name": "double1", "path": "double1/imgs/", "startFrame": 1, "endFrame": 66, "nz": 4, "ext": "tif",
             "anno_path": "double1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "double2", "path": "double2/imgs/", "startFrame": 1, "endFrame": 75, "nz": 4, "ext": "tif",
             "anno_path": "double2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "double3", "path": "double3/imgs/", "startFrame": 1, "endFrame": 80, "nz": 4, "ext": "tif",
             "anno_path": "double3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "double4", "path": "double4/imgs/", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "tif",
             "anno_path": "double4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "double5", "path": "double5/imgs/", "startFrame": 1, "endFrame": 473, "nz": 4, "ext": "tif",
             "anno_path": "double5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublebicycle", "path": "doublebicycle/imgs/", "startFrame": 1, "endFrame": 207, "nz": 4,
             "ext": "tif", "anno_path": "doublebicycle/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar", "path": "doublecar/imgs/", "startFrame": 1, "endFrame": 196, "nz": 4, "ext": "tif",
             "anno_path": "doublecar/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar1", "path": "doublecar1/imgs/", "startFrame": 1, "endFrame": 200, "nz": 4, "ext": "tif",
             "anno_path": "doublecar1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar2", "path": "doublecar2/imgs/", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "tif",
             "anno_path": "doublecar2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar3", "path": "doublecar3/imgs/", "startFrame": 1, "endFrame": 196, "nz": 4, "ext": "tif",
             "anno_path": "doublecar3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar4", "path": "doublecar4/imgs/", "startFrame": 1, "endFrame": 152, "nz": 4, "ext": "tif",
             "anno_path": "doublecar4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar5", "path": "doublecar5/imgs/", "startFrame": 1, "endFrame": 97, "nz": 4, "ext": "tif",
             "anno_path": "doublecar5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar6", "path": "doublecar6/imgs/", "startFrame": 1, "endFrame": 394, "nz": 4, "ext": "tif",
             "anno_path": "doublecar6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar7", "path": "doublecar7/imgs/", "startFrame": 1, "endFrame": 299, "nz": 4, "ext": "tif",
             "anno_path": "doublecar7/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar8", "path": "doublecar8/imgs/", "startFrame": 1, "endFrame": 198, "nz": 4, "ext": "tif",
             "anno_path": "doublecar8/groundtruth_rect.txt", "object_class": "person"},
            {"name": "electriccar", "path": "electriccar/imgs/", "startFrame": 1, "endFrame": 73, "nz": 4, "ext": "tif",
             "anno_path": "electriccar/groundtruth_rect.txt", "object_class": "person"},
            {"name": "electriccar1", "path": "electriccar1/imgs/", "startFrame": 1, "endFrame": 121, "nz": 4,
             "ext": "tif", "anno_path": "electriccar1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "girl", "path": "girl/imgs/", "startFrame": 1, "endFrame": 300, "nz": 4, "ext": "tif",
             "anno_path": "girl/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human", "path": "human/imgs/", "startFrame": 1, "endFrame": 192, "nz": 4, "ext": "tif",
             "anno_path": "human/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human1", "path": "human1/imgs/", "startFrame": 1, "endFrame": 109, "nz": 4, "ext": "tif",
             "anno_path": "human1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human2", "path": "human2/imgs/", "startFrame": 1, "endFrame": 115, "nz": 4, "ext": "tif",
             "anno_path": "human2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human3", "path": "human3/imgs/", "startFrame": 1, "endFrame": 345, "nz": 4, "ext": "tif",
             "anno_path": "human3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human4", "path": "human4/imgs/", "startFrame": 1, "endFrame": 146, "nz": 4, "ext": "tif",
             "anno_path": "human4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human5", "path": "human5/imgs/", "startFrame": 1, "endFrame": 200, "nz": 4, "ext": "tif",
             "anno_path": "human5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human6", "path": "human6/imgs/", "startFrame": 1, "endFrame": 150, "nz": 4, "ext": "tif",
             "anno_path": "human6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human7", "path": "human7/imgs/", "startFrame": 1, "endFrame": 77, "nz": 4, "ext": "tif",
             "anno_path": "human7/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human8", "path": "human8/imgs/", "startFrame": 1, "endFrame": 200, "nz": 4, "ext": "tif",
             "anno_path": "human8/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human9", "path": "human9/imgs/", "startFrame": 1, "endFrame": 143, "nz": 4, "ext": "tif",
             "anno_path": "human9/groundtruth_rect.txt", "object_class": "person"},
            {"name": "man", "path": "man/imgs/", "startFrame": 1, "endFrame": 66, "nz": 4, "ext": "tif",
             "anno_path": "man/groundtruth_rect.txt", "object_class": "person"},
            {"name": "man1", "path": "man1/imgs/", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "tif",
             "anno_path": "man1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "man2", "path": "man2/imgs/", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "tif",
             "anno_path": "man2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "man3", "path": "man3/imgs/", "startFrame": 1, "endFrame": 324, "nz": 4, "ext": "tif",
             "anno_path": "man3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "many_man", "path": "many_man/imgs/", "startFrame": 1, "endFrame": 162, "nz": 4, "ext": "tif",
             "anno_path": "many_man/groundtruth_rect.txt", "object_class": "person"},
            {"name": "motorcycle", "path": "motorcycle/imgs/", "startFrame": 1, "endFrame": 153, "nz": 4, "ext": "tif",
             "anno_path": "motorcycle/groundtruth_rect.txt", "object_class": "person"},
            {"name": "motorcycle1", "path": "motorcycle1/imgs/", "startFrame": 1, "endFrame": 98, "nz": 4, "ext": "tif",
             "anno_path": "motorcycle1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "triple", "path": "triple/imgs/", "startFrame": 1, "endFrame": 384, "nz": 4, "ext": "tif",
             "anno_path": "triple/groundtruth_rect.txt", "object_class": "person"},
            {"name": "triple1", "path": "triple1/imgs/", "startFrame": 1, "endFrame": 50, "nz": 4, "ext": "tif",
             "anno_path": "triple1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "triple2", "path": "triple2/imgs/", "startFrame": 1, "endFrame": 199, "nz": 4, "ext": "tif",
             "anno_path": "triple2/groundtruth_rect.txt", "object_class": "person"}]

        return sequence_info_list
