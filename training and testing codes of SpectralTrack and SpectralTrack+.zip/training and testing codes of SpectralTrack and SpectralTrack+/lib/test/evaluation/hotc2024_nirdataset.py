import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text


class hotc2024_nirDataset(BaseDataset):
    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.hotc2024_nir_path
        self.sequence_info_list = self._get_sequence_info_list()

    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_info_list])

    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        nz = sequence_info['nz']
        ext = sequence_info['ext']
        start_frame = sequence_info['startFrame']
        end_frame = sequence_info['endFrame']

        init_omit = 0
        if 'initOmit' in sequence_info:
            init_omit = sequence_info['initOmit']

        frames = ['{base_path}/{sequence_path}/{frame:0{nz}}.{ext}'.format(base_path=self.base_path,
                                                                           sequence_path=sequence_path, frame=frame_num,
                                                                           nz=nz, ext=ext) for frame_num in
                  range(start_frame + init_omit, end_frame + 1)]

        anno_path = '{}/{}'.format(self.base_path, sequence_info['anno_path'])

        ground_truth_rect = load_text(str(anno_path), delimiter=(',', None), dtype=np.float64, backend='numpy')

        return Sequence(sequence_info['name'], frames, 'hotc2024_nir', ground_truth_rect[init_omit:, :],
                        object_class=sequence_info['object_class'])

    def __len__(self):
        return len(self.sequence_info_list)

    def _get_sequence_info_list(self):
        sequence_info_list = [
            {"name": "basketball2", "path": "basketball2", "startFrame": 1, "endFrame": 802, "nz": 4, "ext": "png",
             "anno_path": "basketball2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car42", "path": "car42", "startFrame": 1, "endFrame": 87, "nz": 4, "ext": "png",
             "anno_path": "car42/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car43", "path": "car43", "startFrame": 1, "endFrame": 116, "nz": 4, "ext": "png",
             "anno_path": "car43/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car44", "path": "car44", "startFrame": 1, "endFrame": 130, "nz": 4, "ext": "png",
             "anno_path": "car44/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car45", "path": "car45", "startFrame": 1, "endFrame": 107, "nz": 4, "ext": "png",
             "anno_path": "car45/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car46", "path": "car46", "startFrame": 1, "endFrame": 155, "nz": 4, "ext": "png",
             "anno_path": "car46/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car47", "path": "car47", "startFrame": 1, "endFrame": 71, "nz": 4, "ext": "png",
             "anno_path": "car47/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car48", "path": "car48", "startFrame": 1, "endFrame": 138, "nz": 4, "ext": "png",
             "anno_path": "car48/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car54", "path": "car54", "startFrame": 1, "endFrame": 95, "nz": 4, "ext": "png",
             "anno_path": "car54/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car55", "path": "car55", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "png",
             "anno_path": "car55/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car56", "path": "car56", "startFrame": 1, "endFrame": 130, "nz": 4, "ext": "png",
             "anno_path": "car56/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car57", "path": "car57", "startFrame": 1, "endFrame": 93, "nz": 4, "ext": "png",
             "anno_path": "car57/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car58", "path": "car58", "startFrame": 1, "endFrame": 137, "nz": 4, "ext": "png",
             "anno_path": "car58/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car65", "path": "car65", "startFrame": 1, "endFrame": 136, "nz": 4, "ext": "png",
             "anno_path": "car65/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car66", "path": "car66", "startFrame": 1, "endFrame": 89, "nz": 4, "ext": "png",
             "anno_path": "car66/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car67", "path": "car67", "startFrame": 1, "endFrame": 137, "nz": 4, "ext": "png",
             "anno_path": "car67/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car68", "path": "car68", "startFrame": 1, "endFrame": 130, "nz": 4, "ext": "png",
             "anno_path": "car68/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car69", "path": "car69", "startFrame": 1, "endFrame": 83, "nz": 4, "ext": "png",
             "anno_path": "car69/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car70", "path": "car70", "startFrame": 1, "endFrame": 214, "nz": 4, "ext": "png",
             "anno_path": "car70/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car71", "path": "car71", "startFrame": 1, "endFrame": 129, "nz": 4, "ext": "png",
             "anno_path": "car71/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car72", "path": "car72", "startFrame": 1, "endFrame": 152, "nz": 4, "ext": "png",
             "anno_path": "car72/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car73", "path": "car73", "startFrame": 1, "endFrame": 135, "nz": 4, "ext": "png",
             "anno_path": "car73/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car74", "path": "car74", "startFrame": 1, "endFrame": 108, "nz": 4, "ext": "png",
             "anno_path": "car74/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car75", "path": "car75", "startFrame": 1, "endFrame": 165, "nz": 4, "ext": "png",
             "anno_path": "car75/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car86", "path": "car86", "startFrame": 1, "endFrame": 114, "nz": 4, "ext": "png",
             "anno_path": "car86/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pedestrian6", "path": "pedestrian6", "startFrame": 1, "endFrame": 459, "nz": 4, "ext": "png",
             "anno_path": "pedestrian6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rider10", "path": "rider10", "startFrame": 1, "endFrame": 211, "nz": 4, "ext": "png",
             "anno_path": "rider10/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rider14", "path": "rider14", "startFrame": 1, "endFrame": 261, "nz": 4, "ext": "png",
             "anno_path": "rider14/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rider15", "path": "rider15", "startFrame": 1, "endFrame": 155, "nz": 4, "ext": "png",
             "anno_path": "rider15/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rider9", "path": "rider9", "startFrame": 1, "endFrame": 210, "nz": 4, "ext": "png",
             "anno_path": "rider9/groundtruth_rect.txt", "object_class": "person"}]

        return sequence_info_list
