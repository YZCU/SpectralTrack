import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text


class hotc2024_visDataset(BaseDataset):
    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.hotc2024_vis_path
        self.sequence_info_list = self._get_sequence_info_list()

    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_info_list])

    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        nz = sequence_info['nz']
        ext = sequence_info['ext']
        start_frame = sequence_info['startFrame']
        end_frame = sequence_info['endFrame']

        init_omit = 0
        if 'initOmit' in sequence_info:
            init_omit = sequence_info['initOmit']

        frames = ['{base_path}/{sequence_path}/{frame:0{nz}}.{ext}'.format(base_path=self.base_path,
                                                                           sequence_path=sequence_path, frame=frame_num,
                                                                           nz=nz, ext=ext) for frame_num in
                  range(start_frame + init_omit, end_frame + 1)]

        anno_path = '{}/{}'.format(self.base_path, sequence_info['anno_path'])

        ground_truth_rect = load_text(str(anno_path), delimiter=(',', None), dtype=np.float64, backend='numpy')

        return Sequence(sequence_info['name'], frames, 'hotc2024_vis', ground_truth_rect[init_omit:, :],
                        object_class=sequence_info['object_class'])

    def __len__(self):
        return len(self.sequence_info_list)

    def _get_sequence_info_list(self):
        sequence_info_list = [
            {"name": "L_basketball", "path": "L_basketball", "startFrame": 1, "endFrame": 984, "nz": 4, "ext": "png",
             "anno_path": "L_basketball/groundtruth_rect.txt", "object_class": "person"},
            {"name": "L_basketball2", "path": "L_basketball2", "startFrame": 1, "endFrame": 1000, "nz": 4, "ext": "png",
             "anno_path": "L_basketball2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "L_basketball_person", "path": "L_basketball_person", "startFrame": 1, "endFrame": 697, "nz": 4,
             "ext": "png", "anno_path": "L_basketball_person/groundtruth_rect.txt", "object_class": "person"},
            {"name": "L_car2", "path": "L_car2", "startFrame": 1, "endFrame": 803, "nz": 4, "ext": "png",
             "anno_path": "L_car2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "L_car3", "path": "L_car3", "startFrame": 1, "endFrame": 373, "nz": 4, "ext": "png",
             "anno_path": "L_car3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "L_person", "path": "L_person", "startFrame": 1, "endFrame": 945, "nz": 4, "ext": "png",
             "anno_path": "L_person/groundtruth_rect.txt", "object_class": "person"},
            {"name": "L_person7", "path": "L_person7", "startFrame": 1, "endFrame": 281, "nz": 4, "ext": "png",
             "anno_path": "L_person7/groundtruth_rect.txt", "object_class": "person"},
            {"name": "L_person8", "path": "L_person8", "startFrame": 1, "endFrame": 849, "nz": 4, "ext": "png",
             "anno_path": "L_person8/groundtruth_rect.txt", "object_class": "person"},
            {"name": "L_person9", "path": "L_person9", "startFrame": 1, "endFrame": 244, "nz": 4, "ext": "png",
             "anno_path": "L_person9/groundtruth_rect.txt", "object_class": "person"},
            {"name": "L_runner", "path": "L_runner", "startFrame": 1, "endFrame": 1000, "nz": 4, "ext": "png",
             "anno_path": "L_runner/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_jump2", "path": "S_jump2", "startFrame": 1, "endFrame": 614, "nz": 4, "ext": "png",
             "anno_path": "S_jump2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_person2", "path": "S_person2", "startFrame": 1, "endFrame": 574, "nz": 4, "ext": "png",
             "anno_path": "S_person2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_runner1", "path": "S_runner1", "startFrame": 1, "endFrame": 991, "nz": 4, "ext": "png",
             "anno_path": "S_runner1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_runner2", "path": "S_runner2", "startFrame": 1, "endFrame": 308, "nz": 4, "ext": "png",
             "anno_path": "S_runner2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_soccer1", "path": "S_soccer1", "startFrame": 1, "endFrame": 581, "nz": 4, "ext": "png",
             "anno_path": "S_soccer1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_soccer3", "path": "S_soccer3", "startFrame": 1, "endFrame": 417, "nz": 4, "ext": "png",
             "anno_path": "S_soccer3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_soccer4", "path": "S_soccer4", "startFrame": 1, "endFrame": 574, "nz": 4, "ext": "png",
             "anno_path": "S_soccer4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_volleyball1", "path": "S_volleyball1", "startFrame": 1, "endFrame": 774, "nz": 4, "ext": "png",
             "anno_path": "S_volleyball1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_walker", "path": "S_walker", "startFrame": 1, "endFrame": 994, "nz": 4, "ext": "png",
             "anno_path": "S_walker/groundtruth_rect.txt", "object_class": "person"},
            {"name": "S_warmup", "path": "S_warmup", "startFrame": 1, "endFrame": 304, "nz": 4, "ext": "png",
             "anno_path": "S_warmup/groundtruth_rect.txt", "object_class": "person"},
            {"name": "backpack4", "path": "backpack4", "startFrame": 1, "endFrame": 275, "nz": 4, "ext": "png",
             "anno_path": "backpack4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "ball&mirror10", "path": "ball&mirror10", "startFrame": 1, "endFrame": 550, "nz": 4, "ext": "png",
             "anno_path": "ball&mirror10/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cards6", "path": "cards6", "startFrame": 1, "endFrame": 450, "nz": 4, "ext": "png",
             "anno_path": "cards6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "clamp", "path": "clamp", "startFrame": 1, "endFrame": 537, "nz": 4, "ext": "png",
             "anno_path": "clamp/groundtruth_rect.txt", "object_class": "person"},
            {"name": "clamp2", "path": "clamp2", "startFrame": 1, "endFrame": 624, "nz": 4, "ext": "png",
             "anno_path": "clamp2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "clamp3", "path": "clamp3", "startFrame": 1, "endFrame": 832, "nz": 4, "ext": "png",
             "anno_path": "clamp3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cloth3", "path": "cloth3", "startFrame": 1, "endFrame": 350, "nz": 4, "ext": "png",
             "anno_path": "cloth3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cranberries7", "path": "cranberries7", "startFrame": 1, "endFrame": 500, "nz": 4, "ext": "png",
             "anno_path": "cranberries7/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cup", "path": "cup", "startFrame": 1, "endFrame": 704, "nz": 4, "ext": "png",
             "anno_path": "cup/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cup2", "path": "cup2", "startFrame": 1, "endFrame": 578, "nz": 4, "ext": "png",
             "anno_path": "cup2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cup3", "path": "cup3", "startFrame": 1, "endFrame": 493, "nz": 4, "ext": "png",
             "anno_path": "cup3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cup4", "path": "cup4", "startFrame": 1, "endFrame": 511, "nz": 4, "ext": "png",
             "anno_path": "cup4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cup5", "path": "cup5", "startFrame": 1, "endFrame": 725, "nz": 4, "ext": "png",
             "anno_path": "cup5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cup6", "path": "cup6", "startFrame": 1, "endFrame": 527, "nz": 4, "ext": "png",
             "anno_path": "cup6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "dice3", "path": "dice3", "startFrame": 1, "endFrame": 275, "nz": 4, "ext": "png",
             "anno_path": "dice3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "drone4", "path": "drone4", "startFrame": 1, "endFrame": 325, "nz": 4, "ext": "png",
             "anno_path": "drone4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "dronecam4", "path": "dronecam4", "startFrame": 1, "endFrame": 460, "nz": 4, "ext": "png",
             "anno_path": "dronecam4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "droneshow2", "path": "droneshow2", "startFrame": 1, "endFrame": 450, "nz": 4, "ext": "png",
             "anno_path": "droneshow2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "duck4", "path": "duck4", "startFrame": 1, "endFrame": 375, "nz": 4, "ext": "png",
             "anno_path": "duck4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "esophagectomy1", "path": "esophagectomy1", "startFrame": 1, "endFrame": 400, "nz": 4,
             "ext": "png", "anno_path": "esophagectomy1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "football1", "path": "football1", "startFrame": 1, "endFrame": 300, "nz": 4, "ext": "png",
             "anno_path": "football1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "football2", "path": "football2", "startFrame": 1, "endFrame": 325, "nz": 4, "ext": "png",
             "anno_path": "football2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "hat", "path": "hat", "startFrame": 1, "endFrame": 585, "nz": 4, "ext": "png",
             "anno_path": "hat/groundtruth_rect.txt", "object_class": "person"},
            {"name": "heartsurgery2", "path": "heartsurgery2", "startFrame": 1, "endFrame": 385, "nz": 4, "ext": "png",
             "anno_path": "heartsurgery2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "leaf", "path": "leaf", "startFrame": 1, "endFrame": 500, "nz": 4, "ext": "png",
             "anno_path": "leaf/groundtruth_rect.txt", "object_class": "person"},
            {"name": "leaves5", "path": "leaves5", "startFrame": 1, "endFrame": 875, "nz": 4, "ext": "png",
             "anno_path": "leaves5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "officechair2", "path": "officechair2", "startFrame": 1, "endFrame": 775, "nz": 4, "ext": "png",
             "anno_path": "officechair2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "oranges5", "path": "oranges5", "startFrame": 1, "endFrame": 250, "nz": 4, "ext": "png",
             "anno_path": "oranges5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pen", "path": "pen", "startFrame": 1, "endFrame": 769, "nz": 4, "ext": "png",
             "anno_path": "pen/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pen2", "path": "pen2", "startFrame": 1, "endFrame": 771, "nz": 4, "ext": "png",
             "anno_path": "pen2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pen3", "path": "pen3", "startFrame": 1, "endFrame": 544, "nz": 4, "ext": "png",
             "anno_path": "pen3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pen4", "path": "pen4", "startFrame": 1, "endFrame": 457, "nz": 4, "ext": "png",
             "anno_path": "pen4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "people", "path": "people", "startFrame": 1, "endFrame": 817, "nz": 4, "ext": "png",
             "anno_path": "people/groundtruth_rect.txt", "object_class": "person"},
            {"name": "people2", "path": "people2", "startFrame": 1, "endFrame": 405, "nz": 4, "ext": "png",
             "anno_path": "people2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "people3", "path": "people3", "startFrame": 1, "endFrame": 420, "nz": 4, "ext": "png",
             "anno_path": "people3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "people4", "path": "people4", "startFrame": 1, "endFrame": 591, "nz": 4, "ext": "png",
             "anno_path": "people4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pills5", "path": "pills5", "startFrame": 1, "endFrame": 550, "nz": 4, "ext": "png",
             "anno_path": "pills5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pool12", "path": "pool12", "startFrame": 1, "endFrame": 600, "nz": 4, "ext": "png",
             "anno_path": "pool12/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pool9", "path": "pool9", "startFrame": 1, "endFrame": 450, "nz": 4, "ext": "png",
             "anno_path": "pool9/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rainystreet12", "path": "rainystreet12", "startFrame": 1, "endFrame": 300, "nz": 4, "ext": "png",
             "anno_path": "rainystreet12/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rubik", "path": "rubik", "startFrame": 1, "endFrame": 570, "nz": 4, "ext": "png",
             "anno_path": "rubik/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rubik2", "path": "rubik2", "startFrame": 1, "endFrame": 535, "nz": 4, "ext": "png",
             "anno_path": "rubik2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rubik3", "path": "rubik3", "startFrame": 1, "endFrame": 512, "nz": 4, "ext": "png",
             "anno_path": "rubik3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rubik4", "path": "rubik4", "startFrame": 1, "endFrame": 221, "nz": 4, "ext": "png",
             "anno_path": "rubik4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rubik5", "path": "rubik5", "startFrame": 1, "endFrame": 830, "nz": 4, "ext": "png",
             "anno_path": "rubik5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rubik6", "path": "rubik6", "startFrame": 1, "endFrame": 787, "nz": 4, "ext": "png",
             "anno_path": "rubik6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "whitecup2", "path": "whitecup2", "startFrame": 1, "endFrame": 437, "nz": 4, "ext": "png",
             "anno_path": "whitecup2/groundtruth_rect.txt", "object_class": "person"}]

        return sequence_info_list
