lightweight traing:
SpectralTrack: yzcu.yaml
SpectralTrack+: yzcu+.yaml