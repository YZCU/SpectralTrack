Put the pre-trained model <yzcu.pth.tar> into this path
for training SpectralTrack and SpectralTrack+
